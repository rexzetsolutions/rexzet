<?php
/**
 * The front page template file
 *
 * If the user has selected a static page for their homepage, this is what will
 * appear.
 * Learn more: https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage gs_review
 * @since 1.0
 * @version 1.0
 */

get_header(); ?>
<style type="text/css">
	#cname{
		background: url("<?php bloginfo('template_directory');?>/image/card.png")10px center no-repeat #ffffff;
	}
	#cemail{
		background: url("<?php bloginfo('template_directory');?>/image/email.png")10px center no-repeat #ffffff;
	}
	#cphone{
		background: url("<?php bloginfo('template_directory');?>/image/phone.png")10px center no-repeat #ffffff;
	}
	.home-top-img{
		background: url("<?php bloginfo('template_directory');?>/image/rev.png");
		height: 500px;
    background-position: center;
    background-size: cover;

	}
</style>
<div id="primary" class="content-area">
	<main id="main" class="site-main" role="main">
		<div class="home-top-img">
			<div class="cform">
				<?php echo do_shortcode('[contact-form-7 id="62" title="GET STARTED"]');?>
			</div>
		</div>
	</main><!-- #main -->
</div><!-- #primary -->

<?php get_footer();
