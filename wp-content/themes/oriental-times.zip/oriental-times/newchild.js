jQuery(document).ready(function(){
	jQuery('#postflexslider').show();
	document.getElementById("mobiledate").innerHTML = new Date().toDateString();
});




