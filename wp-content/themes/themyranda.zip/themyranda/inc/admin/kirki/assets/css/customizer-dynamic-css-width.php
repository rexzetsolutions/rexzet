<?php

return '
.wp-full-overlay-sidebar {
  width: WIDTH;
}

.wp-full-overlay.expanded {
  margin-left: WIDTH;
}
';
